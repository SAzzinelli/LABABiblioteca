export default {
  darkMode: false,
  content: ['./index.html','./src/**/*.{js,jsx}'],
  theme: { extend: { colors: { brand:'#033157', macbg:'#f5f5f7' } } },
  plugins: [],
}
