import { useState } from "react";
import { useAuth } from "./AuthContext";

export default function Login({ branding = "LABA – Gestione Attrezzature" }) {
  const { login, register } = useAuth();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ email: "", password: "", name: "", surname: "", matricola: "" });
  const [err, setErr] = useState("");

  const onSubmit = async (e) => {
    e.preventDefault();
    setErr("");
    try {
      if (mode === "login") {
        await login(form.email.trim(), form.password);
      } else {
        const email = form.email.trim();
        if (!/^([a-z0-9]+)\.([a-z0-9]+)@labafirenze\.com$/i.test(email)) throw new Error("Usa una mail nome.cognome@labafirenze.com");
        if (!form.name.trim() || !form.surname.trim() || !form.matricola.trim()) throw new Error("Nome, cognome e matricola sono obbligatori");
        await register({ name: form.name.trim(), surname: form.surname.trim(), email, password: form.password, matricola: form.matricola.trim() });
      }
    } catch (e) {
      const apiErr = e?.response?.data?.error;
      setErr(apiErr || e.message || "Errore");
    }
  };

  return (
    <div className="min-h-screen grid place-items-center bg-neutral-50">
      <form onSubmit={onSubmit} noValidate className="bg-white rounded-2xl shadow p-6 w-full max-w-md space-y-3">
        <div className="text-xl font-semibold">{branding}</div>
        <div className="text-sm text-neutral-500">Accedi o registrati per richiedere prestiti</div>

        {mode === "register" && (
          <>
            <div className="grid grid-cols-2 gap-2">
              <input className="border rounded-xl px-3 py-2" placeholder="Nome" value={form.name} onChange={e=>setForm(f=>({...f, name:e.target.value}))}/>
              <input className="border rounded-xl px-3 py-2" placeholder="Cognome" value={form.surname} onChange={e=>setForm(f=>({...f, surname:e.target.value}))}/>
            </div>
            <input className="border rounded-xl px-3 py-2 w-full" placeholder="Matricola" value={form.matricola} onChange={e=>setForm(f=>({...f, matricola:e.target.value}))}/>
          </>
        )}

        <input
          className="border rounded-xl px-3 py-2 w-full"
          type="text"
          inputMode="email"
          autoCapitalize="off"
          autoCorrect="off"
          spellCheck={false}
          autoComplete="username"
          placeholder="Email LABA (nome.cognome@labafirenze.com)"
          value={form.email}
          onChange={e=>setForm(f=>({...f, email:e.target.value}))}
        />

        <input
          className="border rounded-xl px-3 py-2 w-full"
          type="password"
          autoComplete="current-password"
          placeholder="Password"
          value={form.password}
          onChange={e=>setForm(f=>({...f, password:e.target.value}))}
        />

        {err && <div className="text-red-600 text-sm">{err}</div>}

        <button className="w-full bg-black text-white rounded-xl py-2 font-semibold">{mode==="login" ? "Accedi" : "Crea account"}</button>

        <div className="text-sm text-neutral-600">
          {mode==="login" ? (
            <>Non hai un account?{" "}
              <button type="button" className="underline" onClick={()=>setMode("register")}>Registrati</button></>
          ) : (
            <>Hai già un account?{" "}
              <button type="button" className="underline" onClick={()=>setMode("login")}>Accedi</button></>
          )}
        </div>
      </form>
    </div>
  );
}