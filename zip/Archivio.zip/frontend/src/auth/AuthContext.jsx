import { createContext, useContext, useEffect, useMemo, useState } from "react";
import axios from "axios";

const AuthContext = createContext(null);
export const useAuth = () => useContext(AuthContext);

const KEY = "laba_auth_token_v2";

export default function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem(KEY));
  const [user, setUser] = useState(null);

  const isAuthenticated = !!token;
  const isAdmin = !!(user && user.role === "admin");

  const api = useMemo(() => {
    const inst = axios.create();
    inst.interceptors.request.use((cfg) => {
      if (token) cfg.headers.Authorization = `Bearer ${token}`;
      return cfg;
    });
    return inst;
  }, [token]);

  useEffect(() => {
    if (!token) { setUser(null); return; }
    api.get("/api/auth/me").then(r => setUser(r.data.user)).catch(() => setUser(null));
  }, [token]);

  const login = async (email, password) => {
    const r = await axios.post("/api/auth/login", { email, password });
    localStorage.setItem(KEY, r.data.token);
    setToken(r.data.token);
    setUser(r.data.user);
    return true;
  };

  const register = async ({ name, surname, email, password, phone, matricola }) => {
    const r = await axios.post("/api/auth/register", { name, surname, email, password, phone, matricola });
    localStorage.setItem(KEY, r.data.token);
    setToken(r.data.token);
    setUser(r.data.user);
    return true;
  };

  const logout = () => {
    localStorage.removeItem(KEY);
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ token, user, isAuthenticated, isAdmin, api, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}