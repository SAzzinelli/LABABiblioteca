import React from 'react'
export default function Footer(){
  return <div className="footer">LABA Gestionale v1.2.0 - Creato con ❤️ da Simone Azzinelli</div>
}
