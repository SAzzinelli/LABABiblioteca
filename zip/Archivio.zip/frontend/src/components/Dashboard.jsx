import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../auth/AuthContext";

const fmt = (iso) => (iso ? iso.split("-").reverse().join("/") : "");

export default function Dashboard() {
  const [prestiti, setPrestiti] = useState([]);
  const [inventario, setInventario] = useState([]);
  const [dates, setDates] = useState({});
  const { api, isAdmin } = useAuth();

  useEffect(() => {
    axios.get("/api/prestiti").then(r => setPrestiti(r.data || []));
    axios.get("/api/inventario").then(r => setInventario(r.data || []));
  }, []);

  // Richieste in attesa (solo admin)
  const [richieste, setRichieste] = useState([]);
  useEffect(() => {
    if (!isAdmin) return;
    api.get("/api/richieste", { params: { stato: "in_attesa" } })
      .then(r => setRichieste(Array.isArray(r.data) ? r.data : []))
      .catch(() => setRichieste([]));
  }, [api, isAdmin, prestiti.length]);

  const approveReq = async (id) => {
    try {
      const d = dates[id] || {};
      await api.post(`/api/richieste/${id}/approva`, { data_uscita: d.dal || null, data_rientro: d.al || null });
      const rr = await api.get("/api/richieste", { params: { stato: "in_attesa" } });
      setRichieste(Array.isArray(rr.data) ? rr.data : []);
      const pr = await axios.get("/api/prestiti");
      setPrestiti(pr.data || []);
    } catch (e) {
      alert(e?.response?.data?.error || "Errore approvazione");
    }
  };
  const refuseReq = async (id) => {
    try {
      await api.post(`/api/richieste/${id}/rifiuta`, {});
      const rr = await api.get("/api/richieste", { params: { stato: "in_attesa" } });
      setRichieste(Array.isArray(rr.data) ? rr.data : []);
    } catch (e) {
      alert(e?.response?.data?.error || "Errore rifiuto");
    }
  };

  return (
    <div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className="p-4 rounded-2xl bg-white shadow">
          <div className="text-sm text-neutral-500">Strumenti totali</div>
          <div className="text-2xl font-semibold">{inventario.reduce((a,b)=>a+(Number(b.quantita)||0),0)}</div>
        </div>
        <div className="p-4 rounded-2xl bg-white shadow">
          <div className="text-sm text-neutral-500">In prestito</div>
          <div className="text-2xl font-semibold">{prestiti.filter(p=>!p.data_rientro).length}</div>
        </div>
        <div className="p-4 rounded-2xl bg-white shadow">
          <div className="text-sm text-neutral-500">Esauriti</div>
          <div className="text-2xl font-semibold">{inventario.filter(i=>Number(i.disponibili||0)===0).length}</div>
        </div>
        <div className="p-4 rounded-2xl bg-white shadow">
          <div className="text-sm text-neutral-500">Scaduti</div>
          <div className="text-2xl font-semibold">{prestiti.filter(p=>p.scaduto).length}</div>
        </div>
      </div>

      {isAdmin && (
        <div className="p-4 rounded-2xl bg-white shadow mb-6">
          <div className="flex items-center justify-between mb-3">
            <div className="text-lg font-semibold">Approvazioni necessarie</div>
            <div className="text-sm text-slate-500">{richieste.length}</div>
          </div>
          {richieste.length === 0 ? (
            <div className="text-slate-500 text-sm">Nessuna richiesta in attesa</div>
          ) : (
            <div className="space-y-2">
              {richieste.map(r => (
                <div key={r.id} className="flex flex-col md:flex-row md:items-center justify-between rounded-xl border p-2 bg-slate-50 gap-2">
                  <div className="text-sm">
                    <div className="font-medium">{r.name} {r.surname} <span className="text-slate-500">·</span> {r.inventario_nome}</div>
                    <div className="text-slate-500">{r.email} · {r.matricola || "—"} · {fmt(String(r.data_richiesta || '').slice(0,10))}</div>
                    <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                      <label className="flex items-center gap-2">Dal
                        <input type="date" className="border rounded px-2 py-1"
                          value={(dates[r.id]?.dal) || ""}
                          onChange={e=>setDates(d=>({...d, [r.id]: {...d[r.id], dal: e.target.value}}))} />
                      </label>
                      <label className="flex items-center gap-2">Al
                        <input type="date" className="border rounded px-2 py-1"
                          value={(dates[r.id]?.al) || ""}
                          onChange={e=>setDates(d=>({...d, [r.id]: {...d[r.id], al: e.target.value}}))} />
                      </label>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={()=>approveReq(r.id)} className="px-3 py-1 rounded-xl bg-green-600 text-white">Approva</button>
                    <button onClick={()=>refuseReq(r.id)} className="px-3 py-1 rounded-xl bg-red-600 text-white">Rifiuta</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
