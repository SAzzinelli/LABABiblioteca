import { useEffect, useMemo, useState } from "react";
import { useAuth } from "../auth/AuthContext";
import axios from "axios";

const fmt = (iso) => (iso ? iso.split("-").reverse().join("/") : "");

export default function UserArea() {
  const { api, user } = useAuth();
  const [inventario, setInventario] = useState([]);
  const [mie, setMie] = useState([]);
  const [prestiti, setPrestiti] = useState([]);
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState("");
  const [sel, setSel] = useState(null);
  const [qty, setQty] = useState(1);
  const [dal, setDal] = useState(() => new Date().toISOString().slice(0,10));
  const [al, setAl] = useState("");
  const [units, setUnits] = useState([]);
  const [pickUnits, setPickUnits] = useState(false);
  const [chosen, setChosen] = useState([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    axios.get("/api/inventario").then(r => setInventario(r.data || []));
    api.get("/api/richieste/mie").then(r => setMie(r.data || []));
    axios.get("/api/prestiti").then(r => {
      const list = (r.data || []).filter(p => (p.prestato_email && user?.email) ? p.prestato_email === user.email : (p.chi || "").includes(user?.name || ""));
      setPrestiti(list);
    });
  }, [api, user]);

  useEffect(() => {
    if (!sel) return;
    const params = new URLSearchParams({ inventario_id: sel.id, dal, al });
    api.get(`/api/richieste/availability?${params.toString()}`).then(r => {
      const out = r.data || { units: [], available_generic: 0 };
      setUnits(Array.isArray(out.units) ? out.units.filter(u => u.available) : []);
    });
  }, [api, sel, dal, al]);

  const disponibili = useMemo(() => inventario.map(it => ({
    ...it,
    disponibili: Number(it.disponibili ?? it.qta_disponibile ?? 0)
  })), [inventario]);

  const submitRichiesta = async () => {
    if (!sel) return;
    setErr("");
    const body = { inventario_id: sel.id, quantita: Math.max(1, Number(qty)||1), unita: pickUnits ? chosen : [], note, dal, al };
    try {
      await api.post("/api/richieste", body);
      setOpen(false);
      setNote("");
      setSel(null);
      setQty(1);
      setChosen([]);
      setPickUnits(false);
      const r = await api.get("/api/richieste/mie");
      setMie(r.data || []);
    } catch (e) {
      setErr(e?.response?.data?.error || "Errore richiesta");
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Area utente</h2>

      <div className="grid md:grid-cols-3 gap-4 mb-8">
        <div className="p-4 rounded-2xl shadow bg-white">
          <div className="text-sm text-neutral-500">Prestiti attivi</div>
          <div className="text-3xl font-bold">{prestiti.length}</div>
        </div>
        <div className="p-4 rounded-2xl shadow bg-white">
          <div className="text-sm text-neutral-500">Richieste inviate</div>
          <div className="text-3xl font-bold">{mie.length}</div>
        </div>
        <div className="p-4 rounded-2xl shadow bg-white">
          <div className="text-sm text-neutral-500">Email</div>
          <div className="text-xl font-medium truncate">{user?.email}</div>
        </div>
      </div>

      <div className="mb-6">
        <button className="px-6 py-3 rounded-2xl bg-black text-white font-semibold" onClick={() => setOpen(true)}>
          Richiedi prestito
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-4 z-50" onClick={() => setOpen(false)}>
          <div onClick={e=>e.stopPropagation()} className="bg-white w-full max-w-2xl rounded-2xl p-6 space-y-4">
            <div className="text-lg font-semibold">Seleziona oggetto</div>
            <div className="max-h-56 overflow-auto border rounded-xl">
              <table className="w-full text-sm">
                <thead><tr className="bg-neutral-50"><th className="text-left p-2">Nome</th><th className="text-right p-2">Disponibili</th><th className="p-2"></th></tr></thead>
                <tbody>
                  {disponibili.map(it => (
                    <tr key={it.id} className="border-t">
                      <td className="p-2">{it.nome}</td>
                      <td className="p-2 text-right">{it.disponibili}</td>
                      <td className="p-2 text-right">
                        {it.disponibili > 0 ? (
                          <button className="px-3 py-1 rounded-lg bg-black text-white" onClick={() => setSel(it)}>Scegli</button>
                        ) : (
                          <span className="text-sm text-red-600">Non disponibile</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {sel && (
              <div className="space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  <div className="col-span-2 text-sm">Oggetto: <span className="font-medium">{sel.nome}</span></div>
                  <div>
                    <label className="text-xs text-neutral-500">Quantità</label>
                    <input type="number" min={1} className="w-full border rounded-xl px-2 py-1" value={qty} onChange={e=>setQty(e.target.value)} />
                  </div>
                  <div>
                    <label className="text-xs text-neutral-500">Dal</label>
                    <input type="date" className="w-full border rounded-xl px-2 py-1" value={dal} onChange={e=>setDal(e.target.value)} />
                  </div>
                  <div>
                    <label className="text-xs text-neutral-500">Al (facoltativo)</label>
                    <input type="date" className="w-full border rounded-xl px-2 py-1" value={al} onChange={e=>setAl(e.target.value)} />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <input id="pickUnits" type="checkbox" checked={pickUnits} onChange={e=>{ setPickUnits(e.target.checked); setChosen([]); }} />
                  <label htmlFor="pickUnits" className="text-sm">Seleziona ID univoci (se disponibili)</label>
                </div>

                {pickUnits && (
                  <div className="border rounded-xl p-2 max-h-28 overflow-auto">
                    {units.length === 0 ? (
                      <div className="text-sm text-neutral-500">Nessuna unità disponibile</div>
                    ) : (
                      <div className="flex flex-wrap gap-2">
                        {units.map(u => (
                          <label key={u.name} className={"px-2 py-1 rounded-lg border cursor-pointer " + (chosen.includes(u.name) ? "bg-black text-white" : "")}>
                            <input type="checkbox" className="hidden" checked={chosen.includes(u.name)} onChange={()=>{
                              setChosen(c => c.includes(u.name) ? c.filter(x=>x!==u.name) : [...c, u.name]);
                            }} />
                            {u.name}
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                <textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Note per l'ufficio (facoltative)" className="w-full border rounded-xl p-2" />
                {err && <div className="text-sm text-red-600">{err}</div>}
                <div className="flex gap-2 justify-end">
                  <button className="px-4 py-2 rounded-xl border" onClick={() => { setSel(null); setNote(""); }}>Annulla</button>
                  <button className="px-4 py-2 rounded-xl bg-black text-white" onClick={submitRichiesta}>Invia richiesta</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold mb-2">Prestiti attivi</h3>
          <div className="border rounded-2xl overflow-hidden bg-white">
            <table className="w-full text-sm">
              <thead><tr className="bg-neutral-50"><th className="text-left p-2">Oggetto</th><th className="p-2">Uscita</th><th className="p-2">Rientro</th><th></th></tr></thead>
              <tbody>
                {prestiti.map(p => (
                  <tr key={p.id} className="border-t">
                    <td className="p-2">{p.inventario_nome}</td>
                    <td className="p-2">{fmt(p.data_uscita)}</td>
                    <td className="p-2">{fmt(p.data_rientro)}</td>
                    <td className="p-2 text-right">
                      <ReportButtons prestito={p} />
                    </td>
                  </tr>
                ))}
                {prestiti.length === 0 && <tr><td colSpan={4} className="p-4 text-center text-neutral-500">Nessun prestito attivo</td></tr>}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-2">Le mie richieste</h3>
          <div className="border rounded-2xl overflow-hidden bg-white">
            <table className="w-full text-sm">
              <thead><tr className="bg-neutral-50"><th className="text-left p-2">Oggetto</th><th className="p-2">Stato</th><th className="p-2">Data</th></tr></thead>
              <tbody>
                {mie.map(r => (
                  <tr key={r.id} className="border-t">
                    <td className="p-2">{r.inventario_nome}</td>
                    <td className="p-2">
                      <span className={"px-2 py-1 rounded-full text-xs font-medium " + (r.stato==="approvata"
                        ? "bg-green-100 text-green-700"
                        : r.stato==="rifiutata"
                          ? "bg-red-100 text-red-700"
                          : "bg-amber-100 text-amber-700")}>
                        {r.stato.replace("_", " ")}
                      </span>
                    </td>
                    <td className="p-2">{fmt((r.data_uscita_richiesta || r.data_richiesta || "").slice(0,10))}</td>
                  </tr>
                ))}
                {mie.length === 0 && <tr><td colSpan={3} className="p-4 text-center text-neutral-500">Nessuna richiesta inviata</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

function ReportButtons({ prestito }) {
  const { api } = useAuth();
  const [busy, setBusy] = useState(false);

  const send = async (tipo) => {
    setBusy(true);
    try {
      await api.post("/api/segnalazioni", { tipo, prestito_id: prestito.id, inventario_id: prestito.inventario_id, messaggio: null });
      alert("Segnalazione inviata");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex gap-2">
      <button disabled={busy} onClick={() => send("guasto")} className="px-3 py-1 rounded-lg border">Segnala guasto</button>
      <button disabled={busy} onClick={() => send("ritardo")} className="px-3 py-1 rounded-lg border">Segnala ritardo</button>
      <button disabled={busy} onClick={() => send("assistenza")} className="px-3 py-1 rounded-lg border">Contatta assistenza</button>
    </div>
  );
}
