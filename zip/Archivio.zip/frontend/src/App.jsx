import React, { useState } from "react";
import AuthProvider, { useAuth } from "./auth/AuthContext";
import Login from "./auth/Login";

import Dashboard from "./components/Dashboard.jsx";
import Inventory from "./components/Inventory.jsx";
import Loans from "./components/Loans.jsx";
import Repairs from "./components/Repairs.jsx";
import Footer from "./components/Footer.jsx";

import UserArea from "./user/UserArea.jsx";

// La tua app "vera"
function AppInner() {
  const [tab, setTab] = useState("dashboard");
  const { isAdmin } = useAuth();
  return (
    <div className="min-h-screen flex flex-col">
      <header className="app-header bg-[color:var(--brand)] text-white sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-4">
          <span className="text-xl font-semibold">Gestione Attrezzatura</span>
          <nav className="ml-auto flex gap-2">
  {isAdmin ? (
    <>
      <button className={"nav-pill " + (tab==='dashboard'?'active':'')} onClick={()=>setTab('dashboard')}>📊 Dashboard</button>
      <button className={"nav-pill " + (tab==='inventario'?'active':'')} onClick={()=>setTab('inventario')}>📦 Inventario</button>
      <button className={"nav-pill " + (tab==='prestiti'?'active':'')} onClick={()=>setTab('prestiti')}>📝 Prestiti</button>
      <button className={"nav-pill " + (tab==='riparazioni'?'active':'')} onClick={()=>setTab('riparazioni')}>🛠️ Riparazioni</button>
    </>
  ) : (
    <>
      <button className={"nav-pill " + (tab==='utente'?'active':'')} onClick={()=>setTab('utente')}>👤 Area utente</button>
    </>
  )}
</nav>
            <div className="ml-4"><UserBadge /></div>
        </div>
      </header>

      <main className="flex-1">
        <div className="max-w-6xl mx-auto px-4 py-6">
        {isAdmin ? (
          <>
            {tab==='dashboard' && <Dashboard />}
            {tab==='inventario' && <Inventory />}
            {tab==='prestiti' && <Loans />}
            {tab==='riparazioni' && <Repairs />}
            {tab==='utente' && <UserArea />}
          </>
        ) : (
          <UserArea />
        )}
              </div>
      </main>

      <Footer />
    </div>
  );
function UserBadge() {
  const { user, logout, isAdmin } = useAuth();
  if (!user) return null;
  const initials = (user.name?.[0] || "?") + (user.surname?.[0] || "");
  return (
    <div className="flex items-center gap-2">
      <div className="hidden sm:block text-sm">
        <div className="font-medium leading-tight">{user.name} {user.surname}</div>
        <div className="text-white/80 text-xs">{isAdmin ? "Admin" : "User"} · {user.email}</div>
      </div>
      <div className="w-8 h-8 rounded-full bg-white/20 grid place-items-center font-semibold">{initials}</div>
      <button onClick={logout} className="px-3 py-1 rounded-xl bg-white/10 hover:bg-white/20">Esci</button>
    </div>
  );
}

}

function Gate() {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) return <Login branding="LABA – Gestione Attrezzature" />;
  return <AppInner />;
}

export default function App() {
  return (
    <AuthProvider>
      <Gate />
    </AuthProvider>
  );
}
