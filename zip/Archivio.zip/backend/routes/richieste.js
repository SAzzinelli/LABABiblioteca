// backend/routes/richieste.js
import express from "express";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { addRichiesta, listRichieste, getRichiesta, decideRichiesta, deleteRichiesta } from "../models/richieste.js";
import { addPrestito, unitAvailability } from "../models/prestiti.js";
import { getById as getUserById } from "../models/users.js";

const router = express.Router();

// Availability helper for UI
router.get("/availability", requireAuth, (req, res) => {
  try {
    const { inventario_id, dal=null, al=null } = req.query || {};
    const id = Number(inventario_id);
    if (!id) return res.status(400).json({ error: "inventario_id mancante" });
    const out = unitAvailability({ inventario_id: id, dal: dal || null, al: al || null });
    res.json(out);
  } catch (e) {
    res.status(400).json({ error: e.message || "Errore disponibilità" });
  }
});

// USER: crea richiesta
router.post("/", requireAuth, (req, res) => {
  try {
    const { inventario_id, quantita=1, unita=[], note=null, dal=null, al=null } = req.body || {};
    if (!inventario_id) return res.status(400).json({ error: "inventario_id mancante" });

    // verifica disponibilità
    const dalEff = dal || new Date().toISOString().slice(0,10);
    const alEff = al || null;
    const avail = unitAvailability({ inventario_id, dal: dalEff, al: alEff });
    const qty = Math.max(1, Number(quantita) || 1);
    if (Array.isArray(unita) && unita.length > 0) {
      const m = new Map((avail.units || []).map(u => [String(u.name), u]));
      const bad = unita.filter(n => !m.get(String(n)) || !m.get(String(n)).available);
      if (bad.length) return res.status(400).json({ error: `Unità non disponibili: ${bad.join(", ")}` });
      if (unita.length !== qty) return res.status(400).json({ error: "Quantità non coerente con le unità selezionate" });
    } else {
      if ((avail.available_generic || 0) < qty) {
        return res.status(400).json({ error: "Oggetto non disponibile (prenotato o in riparazione)" });
      }
    }

    const r = addRichiesta({ user_id: req.user.id, inventario_id, quantita: qty, unita, note, dal: dalEff, al: alEff });
    res.json(r);
  } catch (e) {
    res.status(400).json({ error: e.message || "Errore" });
  }
});

// USER: mie richieste
router.get("/mie", requireAuth, (req, res) => {
  res.json(listRichieste({ user_id: req.user.id }));
});

// ADMIN: elenco (filtrabile per stato)
router.get("/", requireAuth, requireRole("admin"), (req, res) => {
  const { stato=null } = req.query || {};
  res.json(listRichieste({ stato: stato || null }));
});

// ADMIN: approva -> crea PRESTITO
router.post("/:id/approva", requireAuth, requireRole("admin"), (req, res) => {
  try {
    const rid = Number(req.params.id);
    const r = getRichiesta(rid);
    if (!r) return res.status(404).json({ error: "Richiesta non trovata" });

    const { data_rientro=null, data_uscita=null, note=null } = req.body || {};
    const user = getUserById(r.user_id);

    const p = addPrestito({
      inventario_id: r.inventario_id,
      quantita: r.quantita,
      unita: r.unita,
      chi: `${(user?.name||"").trim()} ${(user?.surname||"").trim()}`.trim() || user?.email,
      data_uscita: data_uscita || r.data_uscita_richiesta || new Date().toISOString().slice(0,10),
      data_rientro: data_rientro || r.data_rientro_richiesta || null,
      note: note || r.note || null,
      prestato_nome: user?.name || null,
      prestato_cognome: user?.surname || null,
      prestato_email: user?.email || null,
      prestato_matricola: user?.matricola || null,
      prestato_telefono: user?.phone || null
    });
    decideRichiesta(rid, { stato: "approvata", deciso_da: req.user.id, decisione_note: null });
    res.json({ ok: true, prestito: p });
  } catch (e) {
    res.status(400).json({ error: e.message || "Errore" });
  }
});

// ADMIN: rifiuta
router.post("/:id/rifiuta", requireAuth, requireRole("admin"), (req, res) => {
  try {
    const rid = Number(req.params.id);
    const { decisione_note=null } = req.body || {};
    const r = decideRichiesta(rid, { stato: "rifiutata", deciso_da: req.user.id, decisione_note });
    res.json(r);
  } catch (e) {
    res.status(400).json({ error: e.message || "Errore" });
  }
});

// ADMIN: elimina
router.delete("/:id", requireAuth, requireRole("admin"), (req, res) => {
  res.json(deleteRichiesta(Number(req.params.id)));
});

export default router;
