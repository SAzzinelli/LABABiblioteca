// backend/routes/auth.js
import express from "express";
import { createUser, ensureAdmin, verifyCredentials, getById } from "../models/users.js";
import { signToken, requireAuth } from "../middleware/auth.js";

const router = express.Router();

// Ensure an admin exists on boot
router.post("/bootstrap-admin", (req, res) => {
  try {
    const email = "admin@labafirenze.com";
    const password = "laba2025";
    const u = ensureAdmin({ email, password });
    res.json({ ok: true, admin: { id: u.id, email: u.email }});
  } catch (e) {
    res.status(500).json({ error: e.message || "Errore" });
  }
});

router.post("/register", (req, res) => {
  try {
    const { name, surname, email, password, phone = null, matricola = null } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: "Email e password sono obbligatorie" });

    const e = String(email).trim().toLowerCase();
    if (e === "admin@labafirenze.com") return res.status(400).json({ error: "Queste credenziali sono riservate all'amministratore" });

    // Consenti SOLO dominio @labafirenze.com e local-part "nome.cognome"
    const m = /^([a-z0-9]+)\.([a-z0-9]+)@labafirenze\.com$/i.exec(e);
    if (!m) return res.status(400).json({ error: "Registrazione consentita solo con email nome.cognome@labafirenze.com" });

    if (!name || !surname || !matricola) {
      return res.status(400).json({ error: "Nome, Cognome e Matricola sono obbligatori" });
    }

    const user = createUser({ name, surname, email: e, password, phone, matricola, role: "user" });
    const token = signToken({ id: user.id, email: user.email, name: user.name, surname: user.surname, role: user.role });
    res.json({ token, user });
  } catch (e) {
    res.status(400).json({ error: e.message || "Errore" });
  }
});

router.post("/login", (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ error: "Email e password sono obbligatorie" });

    const e = String(email).trim().toLowerCase();

    // Login amministratore fisso: admin@labafirenze.com / laba2025
    if (e === "admin@labafirenze.com") {
      if (password !== "laba2025") return res.status(401).json({ error: "Credenziali non valide" });
      const u = ensureAdmin({ email: "admin@labafirenze.com", password: "laba2025" });
      const token = signToken({ id: u.id, email: u.email, name: u.name, surname: u.surname, role: "admin" });
      return res.json({ token, user: { id: u.id, email: u.email, name: u.name, surname: u.surname, role: "admin" } });
    }

    // Utenti normali (devono già esistere o registrarsi)
    const user = verifyCredentials(e, password);
    if (!user) return res.status(401).json({ error: "Credenziali non valide" });
    const token = signToken({ id: user.id, email: user.email, name: user.name, surname: user.surname, role: user.role });
    res.json({ token, user });
  } catch (e) {
    res.status(500).json({ error: e.message || "Errore" });
  }
});

router.get("/me", requireAuth, (req, res) => {
  const user = getById(req.user.id);
  res.json({ user });
});

export default router;
