// backend/models/users.js
import { db } from "./db.js";
import crypto from "crypto";

const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || "admin@local").toLowerCase();

function mustUseLabaDomain(email, role) {
  const e = String(email||"").trim().toLowerCase();
  if (role === 'admin' || e === ADMIN_EMAIL) return false; // admins bypass
  return !/@labafirenze\.com$/.test(e);
}

// bootstrap
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    surname TEXT,
    email TEXT UNIQUE NOT NULL,
    phone TEXT,
    matricola TEXT,
    role TEXT DEFAULT 'user',
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE INDEX IF NOT EXISTS idx_users_email ON users (email);
`);

function hashPw(pw) {
  // simple scrypt hash (salted)
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(String(pw), salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

function verifyPw(pw, stored) {
  try {
    const [algo, salt, hash] = String(stored).split("$");
    if (algo !== "scrypt") return false;
    const check = crypto.scryptSync(String(pw), salt, 64).toString("hex");
    return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(check, "hex"));
  } catch {
    return false;
  }
}

export function getByEmail(email) {
  return db.prepare("SELECT id, name, surname, email, phone, matricola, role, password_hash FROM users WHERE email=?").get(String(email).toLowerCase().trim());
}

export function getById(id) {
  return db.prepare("SELECT id, name, surname, email, phone, matricola, role FROM users WHERE id=?").get(id);
}

export function createUser({ name, surname, email, phone=null, matricola=null, role='user', password }) {
  const exists = getByEmail(email);
  if (exists) throw new Error("Email già registrata");
  if (mustUseLabaDomain(email, role)) throw new Error("Registrazione consentita solo con email @labafirenze.com");
  const info = db.prepare(`
    INSERT INTO users (name, surname, email, phone, matricola, role, password_hash)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name?.trim() || null, surname?.trim() || null, String(email).toLowerCase().trim(), phone, matricola, role, hashPw(password));
  return getById(info.lastInsertRowid);
}

export function ensureAdmin({ email, password, name="Admin", surname="LABA" }) {
  const e = String(email || "admin@local").toLowerCase().trim();
  let u = getByEmail(e);
  if (!u) {
    const info = db.prepare(`
      INSERT INTO users (name, surname, email, role, password_hash)
      VALUES (?, ?, ?, 'admin', ?)
    `).run(name, surname, e, hashPw(password || "admin123"));
    u = getById(info.lastInsertRowid);
  }
  return u;
}

export function verifyCredentials(email, password) {
  const row = getByEmail(email);
  if (!row) return null;
  if (!verifyPw(password, row.password_hash)) return null;
  const { password_hash, ...user } = row;
  return user;
}