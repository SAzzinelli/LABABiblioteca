// backend/middleware/auth.js
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";

export function signToken(payload, opts = {}) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "7d", ...opts });
}

export function authOptional(req, _res, next) {
  const hdr = req.headers.authorization || "";
  const m = /^Bearer\s+(.+)$/.exec(hdr);
  if (m) {
    try {
      req.user = jwt.verify(m[1], JWT_SECRET);
    } catch {
      // ignore invalid token
    }
  }
  next();
}

export function requireAuth(req, res, next) {
  const hdr = req.headers.authorization || "";
  const m = /^Bearer\s+(.+)$/.exec(hdr);
  if (!m) return res.status(401).json({ error: "Token mancante" });
  try {
    req.user = jwt.verify(m[1], JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: "Token non valido" });
  }
}

export function requireRole(role = "admin") {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: "Non autenticato" });
    if (req.user.role !== role) return res.status(403).json({ error: "Permesso negato" });
    next();
  };
}